Wrap + written summary (5–10 min)
recap the directions + next steps you locked in
write it down together (live notes, or you type while summarizing)
make sure the next steps feel clear, low-pressure, and doable
follow-up plan (optional)
After-call (optional)
If anything wasn’t written during the wrap: send the summary + links/resources + intros.
