# Switch org/team within same field

Use these when you don’t have deep domain answers, or cause area isn’t clear yet:
