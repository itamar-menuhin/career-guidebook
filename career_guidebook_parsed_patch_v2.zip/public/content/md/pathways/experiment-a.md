# Experiment A

Experiments A–D (overview → longer exposure → project pathway → job-board exploration)

Experiment A — 1-hour overview: broad overview + interest test; canonical intro resource/video (1–2 options)
