# Skill-building plan (career capital)

Use these when you don’t have deep domain answers, or cause area isn’t clear yet:
