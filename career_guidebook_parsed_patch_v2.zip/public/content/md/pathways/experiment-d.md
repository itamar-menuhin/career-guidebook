# Experiment D

Experiments A–D (overview → longer exposure → project pathway → job-board exploration)

Experiment D — job-board exploration: make roles/orgs concrete + bridge theory→action (boards + quick scan method)
