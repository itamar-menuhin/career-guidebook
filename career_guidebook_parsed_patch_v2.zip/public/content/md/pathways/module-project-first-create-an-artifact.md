# Project-first (create an artifact)

Orthogonal modules (cross-cutting, not cause-specific)
Used as additional options when they fit:
