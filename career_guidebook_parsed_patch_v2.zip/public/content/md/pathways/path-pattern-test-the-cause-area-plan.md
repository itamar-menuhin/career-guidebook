# “Test the cause area” plan

Use these when you don’t have deep domain answers, or cause area isn’t clear yet:
