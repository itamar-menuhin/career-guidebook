# Experiment B

Experiments A–D (overview → longer exposure → project pathway → job-board exploration)

Experiment B — longer exposure: course/fellowship/series; field granularity (1–2 options)
