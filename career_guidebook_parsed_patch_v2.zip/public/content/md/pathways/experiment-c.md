# Experiment C

Experiments A–D (overview → longer exposure → project pathway → job-board exploration)

Experiment C — project pathway: hands-on; proof-of-fit; motivation-from-action; also good for people needing a push / impostor syndrome
