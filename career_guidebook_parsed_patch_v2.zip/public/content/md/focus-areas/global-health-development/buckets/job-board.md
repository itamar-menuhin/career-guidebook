## Experiment D — explore specific job boards (intuition + bridge to action)
**Pick 1–2:**
- 80,000 Hours job board (good EA filter for high-impact roles) (80,000 Hours)
- ReliefWeb jobs (humanitarian + development roles; good breadth) (ReliefWeb)
- Devex job search (global development-focused job board) (Devex)
- Impactpool (UN + international orgs; public health roles) (Impactpool)
- Tiny scanning method (10–25 min): collect 8–12 roles → label role-types → circle 3 roles + 2 repeating skill gaps → turn into one “direction to test” + one next step.
