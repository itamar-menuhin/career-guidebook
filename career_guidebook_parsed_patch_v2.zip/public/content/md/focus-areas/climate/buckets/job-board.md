## Experiment D — job-board exploration (intuition + bridge to action)
**Pick 1–2:**
- Probably Good job board (filtered to Climate Change) jobs.probablygood.org
- Climatebase jobs Climatebase.org
- 80,000 Hours job board (fewer climate roles, but often higher “EA filter”). 80,000 Hours
