---
kind: focus_area_bucket
focus_area_id: climate
bucket: job-board
title: Job board scan (real roles)
curated_cards: []
---

Experiment D — job-board exploration (intuition + bridge to action)
Pick 1–2:
Probably Good job board (filtered to Climate Change) jobs.probablygood.org
Climatebase jobs Climatebase.org
80,000 Hours job board (fewer climate roles, but often higher “EA filter”). 80,000 Hours
