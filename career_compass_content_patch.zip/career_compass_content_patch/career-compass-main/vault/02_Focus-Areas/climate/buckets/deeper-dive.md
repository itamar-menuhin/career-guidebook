---
kind: focus_area_bucket
focus_area_id: climate
bucket: deeper-dive
title: Deeper dive (2–6 hours)
curated_cards: []
---

Experiment B — longer exposure (course/fellowship/series)
Pick 1:
Terra.do — “Climate Change: Learning for Action” (structured 12-week “map the space + find your role” style). Terra+1
Project Drawdown — Climate Solutions 101 playlist (self-paced series, broad but concrete). YouTube
