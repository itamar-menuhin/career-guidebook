---
kind: focus_area_bucket
focus_area_id: climate
bucket: quick-taste
title: Quick taste (≈1 hour)
curated_cards: []
---

Experiment A — introductory (< 1 hour): broad overview + test interest
Pick 1:
Probably Good — Climate Change: Impact-Focused Overview (EA-ish framing + “what to do about it”). Probably Good
80,000 Hours — Climate change problem profile (skim summary + “best ways of working” sections). 80,000 Hours
Optional YouTube (good-enough, non-EA but clear):
Project Drawdown — Climate Solutions 101 (watch 1 episode that matches their curiosity). YouTube
