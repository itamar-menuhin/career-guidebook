---
kind: focus_area_bucket
focus_area_id: ai-safety
bucket: quick-taste
title: Quick taste (≈1 hour)
curated_cards: []
---

Quick taste (≈1 hour) (choose 1)
Robert Miles — “Intro to AI Safety, Remastered” (video)
DeepMind — “AGI Safety Course” playlist (video course)
Optional alt if they prefer reading: 80,000 Hours AI safety researcher career review
