---
kind: focus_area_bucket
focus_area_id: ai-safety
bucket: job-board
title: Job board scan (real roles)
curated_cards: []
---

Job board scan (real roles) (choose 1–2)
80,000 Hours job board
AISafety.com jobs
Optional alt: EA Opportunities board
Tiny scanning method (10–25 min): collect 8–12 interesting roles → label role-types → circle 3 roles + 2 repeating skill gaps.
