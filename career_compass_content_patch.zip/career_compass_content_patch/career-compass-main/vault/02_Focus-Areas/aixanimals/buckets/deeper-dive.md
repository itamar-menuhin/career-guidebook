---
kind: focus_area_bucket
focus_area_id: aixanimals
bucket: deeper-dive
title: Deeper dive (2–6 hours)
curated_cards: []
---

Experiment B — longer exposure (choose 1)
Canonical pick (evidence/field grounding)
Rethink Priorities series: “How AI is affecting farmed aquatic animals” (deep dive on innovation → deployment → welfare effects; very “EA research-y”). (Rethink Priorities)
Optional alt (structured program)
AI×Animals Fellowship (8-week remote program focused on AI × animal welfare careers). (Effective Altruism)
Futurekind AI Fellowship (12-week program on using AI for animal protection & environment; listed on EA Opportunities). (Effective Altruism)
(These structured programs are newer; I’m including them because they’re explicitly advertised in EA channels, but they’re not as long-established as core 80k/AAC resources.) (Effective Altruism)
