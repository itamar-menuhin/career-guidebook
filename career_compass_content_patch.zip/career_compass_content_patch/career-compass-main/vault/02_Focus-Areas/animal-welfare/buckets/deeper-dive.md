---
kind: focus_area_bucket
focus_area_id: animal-welfare
bucket: deeper-dive
title: Deeper dive (2–6 hours)
curated_cards: []
---

Experiment B — longer exposure (choose 1)
Canonical pick
Animal Advocacy Careers — Introduction to Animal Advocacy Online Course (structured, field-level map + careers) Effective Altruism+1
Optional alt (if they want “real field texture” through conversations)
80,000 Hours podcast episode with Lewis Bollard on factory farming advocacy 80,000 Hours
