---
kind: focus_area_bucket
focus_area_id: biosecurity
bucket: job-board
title: Job board scan (real roles)
curated_cards: []
---

Experiment D — job-board exploration (choose 1–2)
80,000 Hours job board (filter toward biosecurity/pandemic preparedness roles). 80,000 Hours Job Board+1
Optional alt: EA Opportunities for events/fellowships/short programs in biosecurity. Effective Altruism
Tiny scanning method (10–25 min): same as AI safety (8–12 roles → label → circle 3 roles + 2 skill gaps).
