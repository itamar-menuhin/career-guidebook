---
kind: focus_area_bucket
focus_area_id: biosecurity
bucket: hands-on
title: Hands-on trial
curated_cards: []
---

Experiment C — project pathway (make it concrete)
Canonical pick: Oxford Biosecurity Group (OBG) projects (part-time remote research projects; biosecurity + AI-bio intersection). My Site+1
Toe-in-the-water step: browse the projects page; pick 2 projects that seem feasible/interesting; write 2 lines each.
