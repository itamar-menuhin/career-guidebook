---
kind: card
id: global-health-development-charity-entrepreneurship-incubation-program
title: 'Charity Entrepreneurship: Incubation Program'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


