---
kind: card
id: the-life-you-can-save-best-charities
title: 'The Life You Can Save: Best Charities'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


