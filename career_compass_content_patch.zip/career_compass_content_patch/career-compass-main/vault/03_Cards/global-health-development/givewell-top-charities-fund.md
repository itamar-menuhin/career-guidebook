---
kind: card
id: givewell-top-charities-fund
title: 'GiveWell: Top Charities Fund'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


