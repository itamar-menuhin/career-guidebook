---
kind: card
id: givewell-gwwc-youtube-givewell-finds-highly-cost-effective-charities-heres-how
title: 'GiveWell/GWWC YouTube: “GiveWell finds highly cost-effective charities — here’s
  how”'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


