---
kind: card
id: project-gwwc-pledge-drive
title: 'Project: GWWC Pledge Drive'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


