---
kind: card
id: robert-miles-intro-to-ai-safety-remastered
title: 'Robert Miles: “Intro to AI Safety, Remastered”'
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


