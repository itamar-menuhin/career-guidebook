---
kind: card
id: ea-opportunities-board
title: EA Opportunities Board
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


