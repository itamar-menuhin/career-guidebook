---
kind: card
id: 80-000-hours-job-board
title: 80,000 Hours Job Board
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


