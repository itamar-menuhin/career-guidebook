---
kind: card
id: 80-000-hours-ai-safety-researcher-career-review
title: '80,000 Hours: AI safety researcher career review'
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


