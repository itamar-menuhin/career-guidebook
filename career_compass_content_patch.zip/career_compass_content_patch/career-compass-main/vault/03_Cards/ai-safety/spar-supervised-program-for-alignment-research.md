---
kind: card
id: spar-supervised-program-for-alignment-research
title: SPAR (Supervised Program for Alignment Research)
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


