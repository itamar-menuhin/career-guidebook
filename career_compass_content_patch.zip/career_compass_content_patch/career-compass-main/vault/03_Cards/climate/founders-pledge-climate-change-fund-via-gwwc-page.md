---
kind: card
id: founders-pledge-climate-change-fund-via-gwwc-page
title: 'Founders Pledge: Climate Change Fund (via GWWC page)'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


