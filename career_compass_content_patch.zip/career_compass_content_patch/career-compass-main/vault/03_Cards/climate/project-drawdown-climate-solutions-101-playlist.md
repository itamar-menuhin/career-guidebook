---
kind: card
id: project-drawdown-climate-solutions-101-playlist
title: 'Project Drawdown: Climate Solutions 101 (playlist)'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


