---
kind: card
id: project-giving-drive-informed-by-giving-green
title: 'Project: Giving drive informed by Giving Green'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


