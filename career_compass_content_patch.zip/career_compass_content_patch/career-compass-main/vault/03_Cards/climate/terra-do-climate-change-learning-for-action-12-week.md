---
kind: card
id: terra-do-climate-change-learning-for-action-12-week
title: 'Terra.do: Climate Change — Learning for Action (12-week)'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


