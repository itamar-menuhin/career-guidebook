---
kind: card
id: climate-giving-green-effective-climate-giving
title: 'Giving Green: effective climate giving'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


