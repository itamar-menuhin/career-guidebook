---
kind: card
id: climate-80-000-hours-job-board
title: 80,000 Hours job board
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


