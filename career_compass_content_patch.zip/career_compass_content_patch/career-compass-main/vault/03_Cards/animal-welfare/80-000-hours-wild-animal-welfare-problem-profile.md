---
kind: card
id: 80-000-hours-wild-animal-welfare-problem-profile
title: '80,000 Hours: Wild animal welfare problem profile'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


