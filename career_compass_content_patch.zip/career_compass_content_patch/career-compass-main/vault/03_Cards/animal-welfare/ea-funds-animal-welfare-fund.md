---
kind: card
id: ea-funds-animal-welfare-fund
title: 'EA Funds: Animal Welfare Fund'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


