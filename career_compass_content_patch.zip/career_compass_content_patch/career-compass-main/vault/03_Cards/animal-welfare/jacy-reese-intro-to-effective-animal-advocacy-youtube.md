---
kind: card
id: jacy-reese-intro-to-effective-animal-advocacy-youtube
title: 'Jacy Reese: “Intro to effective animal advocacy” (YouTube)'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


