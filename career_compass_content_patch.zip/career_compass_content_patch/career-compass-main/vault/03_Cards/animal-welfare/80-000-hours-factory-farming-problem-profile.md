---
kind: card
id: 80-000-hours-factory-farming-problem-profile
title: '80,000 Hours: Factory farming problem profile'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


