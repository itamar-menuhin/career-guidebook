---
kind: card
id: 80-000-hours-podcast-lewis-bollard-on-factory-farming-advocacy
title: '80,000 Hours podcast: Lewis Bollard on factory farming advocacy'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


