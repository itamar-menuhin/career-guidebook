---
kind: card
id: animal-charity-evaluators-giving-recommendations
title: 'Animal Charity Evaluators: Giving recommendations'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


