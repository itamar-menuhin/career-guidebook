---
kind: card
id: animal-advocacy-careers-intro-to-animal-advocacy-online-course
title: 'Animal Advocacy Careers: Intro to Animal Advocacy Online Course'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


