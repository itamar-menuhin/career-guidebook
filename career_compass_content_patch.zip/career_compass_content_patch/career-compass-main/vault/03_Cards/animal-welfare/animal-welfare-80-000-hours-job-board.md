---
kind: card
id: animal-welfare-80-000-hours-job-board
title: '80,000 Hours: Job board'
focus_area_id: animal-welfare
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


