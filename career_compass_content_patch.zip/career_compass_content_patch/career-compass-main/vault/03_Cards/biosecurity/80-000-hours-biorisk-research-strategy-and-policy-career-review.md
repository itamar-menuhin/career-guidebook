---
kind: card
id: 80-000-hours-biorisk-research-strategy-and-policy-career-review
title: '80,000 Hours: Biorisk research, strategy, and policy (career review)'
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


