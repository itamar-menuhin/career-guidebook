---
kind: card
id: oxford-biosecurity-group-obg-remote-part-time-projects
title: 'Oxford Biosecurity Group (OBG): remote part-time projects'
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


