---
kind: card
id: bluedot-impact-biosecurity-course-30h
title: 'BlueDot Impact: Biosecurity course (~30h)'
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


