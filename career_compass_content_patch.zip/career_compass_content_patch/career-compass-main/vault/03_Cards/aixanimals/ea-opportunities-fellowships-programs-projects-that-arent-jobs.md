---
kind: card
id: ea-opportunities-fellowships-programs-projects-that-arent-jobs
title: EA Opportunities (fellowships/programs/projects that aren’t “jobs”)
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
first_small_step: '

  people who need action to stay motivated, want quick proof-of-fit, or need a push
  past impostor syndrome.'
---

## First small step

people who need action to stay motivated, want quick proof-of-fit, or need a push past impostor syndrome.
