---
kind: card
id: work-on-climate-starter-packs-community
title: Work on Climate (Starter Packs + community)
focus_area_id: aixanimals
bucket: quick-taste
topic: community
commitment: low
good_fit_if:
- Open
first_small_step: pick one Starter Pack (e.g., climate policy / solutions) and do
  the first 1–2 items. Work on Climate+1
---

## First small step
pick one Starter Pack (e.g., climate policy / solutions) and do the first 1–2 items. Work on Climate+1
