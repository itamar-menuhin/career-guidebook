---
kind: card
id: faunalytics-ai-and-animal-advocacy-survey-style
title: 'Faunalytics: “AI and Animal Advocacy” (survey-style)'
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


