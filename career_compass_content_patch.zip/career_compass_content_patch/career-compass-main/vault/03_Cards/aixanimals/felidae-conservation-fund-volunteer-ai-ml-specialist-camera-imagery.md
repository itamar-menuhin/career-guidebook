---
kind: card
id: felidae-conservation-fund-volunteer-ai-ml-specialist-camera-imagery
title: 'Felidae Conservation Fund: Volunteer AI/ML specialist (camera imagery)'
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


