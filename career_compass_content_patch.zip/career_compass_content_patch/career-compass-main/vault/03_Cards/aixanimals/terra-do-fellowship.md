---
kind: card
id: terra-do-fellowship
title: Terra.do fellowship
focus_area_id: aixanimals
bucket: quick-taste
topic: program
commitment: medium
good_fit_if:
- Open (but time-consuming)
first_small_step: look at syllabus + next cohort timing and see if it fits their timeline.
  Terra+1
---

## First small step
look at syllabus + next cohort timing and see if it fits their timeline. Terra+1
