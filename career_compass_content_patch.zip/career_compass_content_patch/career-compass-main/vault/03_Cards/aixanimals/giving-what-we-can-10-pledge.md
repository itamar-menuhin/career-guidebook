---
kind: card
id: giving-what-we-can-10-pledge
title: 'Giving What We Can: 10% Pledge'
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: take the pledge (or start with a smaller % if that’s what fits).
  (Giving What We Can)
---

## First small step
take the pledge (or start with a smaller % if that’s what fits). (Giving What We Can)
