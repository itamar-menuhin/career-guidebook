---
kind: card
id: rethink-priorities-how-ai-is-affecting-farmed-aquatic-animals-series
title: 'Rethink Priorities: “How AI is affecting farmed aquatic animals” (series)'
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


