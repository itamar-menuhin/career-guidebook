---
kind: card
id: org-facing-scoping-note-using-an-rp-ai-for-animals-angle-externally-useful
title: “Org-facing scoping note” using an RP AI-for-animals angle (externally useful)
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


