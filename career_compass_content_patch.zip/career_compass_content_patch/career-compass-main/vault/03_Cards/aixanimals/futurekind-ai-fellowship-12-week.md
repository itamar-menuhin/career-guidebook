---
kind: card
id: futurekind-ai-fellowship-12-week
title: Futurekind AI Fellowship (12-week)
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


