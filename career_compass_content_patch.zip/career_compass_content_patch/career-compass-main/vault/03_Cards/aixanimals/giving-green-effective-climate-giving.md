---
kind: card
id: giving-green-effective-climate-giving
title: Giving Green (effective climate giving)
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: read the current “Top Climate Nonprofits” page; donate if that’s
  part of their plan. Giving Green+1
---

## First small step
read the current “Top Climate Nonprofits” page; donate if that’s part of their plan. Giving Green+1
