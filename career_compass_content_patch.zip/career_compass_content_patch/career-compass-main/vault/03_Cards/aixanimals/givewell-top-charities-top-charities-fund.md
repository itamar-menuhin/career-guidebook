---
kind: card
id: givewell-top-charities-top-charities-fund
title: GiveWell top charities / Top Charities Fund
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: read the top charities page; donate to Top Charities Fund or pick
  a charity. (GiveWell)
---

## First small step
read the top charities page; donate to Top Charities Fund or pick a charity. (GiveWell)
