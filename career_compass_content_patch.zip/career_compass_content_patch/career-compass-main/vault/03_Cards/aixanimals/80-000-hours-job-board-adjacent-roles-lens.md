---
kind: card
id: 80-000-hours-job-board-adjacent-roles-lens
title: 80,000 Hours job board (adjacent roles lens)
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


