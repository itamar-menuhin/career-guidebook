---
kind: card
id: ai-animals-fellowship-8-week-remote
title: AI×Animals Fellowship (8-week, remote)
focus_area_id: aixanimals
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


