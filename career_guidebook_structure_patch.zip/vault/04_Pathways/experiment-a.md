---
kind: pathway
id: experiment-a
title: Quick taste (≈1 hour)
group: How to explore (A–D)
order: 0
---

A fast way to get oriented and test interest without commitment.

Use this as an overview + interest test; pick one canonical intro resource/video.
