---
kind: pathway
id: path-pattern-credentials-pipeline-plan
title: Credentials/pipeline plan
group: Path patterns
order: 7
---

Use a formal program, fellowship, or credential as a structured on-ramp into a new area.
