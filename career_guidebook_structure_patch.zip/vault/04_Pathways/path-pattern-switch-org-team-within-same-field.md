---
kind: pathway
id: path-pattern-switch-org-team-within-same-field
title: Switch org/team within same field
group: Path patterns
order: 2
---

Move to a different team or organization while staying in the same general domain to improve fit, learning, or impact.
