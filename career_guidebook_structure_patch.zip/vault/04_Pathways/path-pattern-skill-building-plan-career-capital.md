---
kind: pathway
id: path-pattern-skill-building-plan-career-capital
title: Skill-building plan (career capital)
group: Path patterns
order: 5
---

Invest in skills, credentials, or portfolio work to unlock higher-impact options later.
