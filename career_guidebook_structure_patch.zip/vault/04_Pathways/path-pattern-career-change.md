---
kind: pathway
id: path-pattern-career-change
title: Career change
group: Path patterns
order: 4
---

A bigger pivot into a new field or role family, usually via deliberate exploration and skill-building steps.
