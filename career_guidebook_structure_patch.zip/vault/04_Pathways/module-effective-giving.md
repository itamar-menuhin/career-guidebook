---
kind: archived
id: module-effective-giving
title: Effective giving
group: Orthogonal modules
---

# Effective giving

Orthogonal modules (cross-cutting, not cause-specific)
Used as additional options when they fit:
