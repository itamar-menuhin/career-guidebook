---
kind: pathway
id: experiment-b
title: Deeper dive (course / fellowship)
group: How to explore (A–D)
order: 0
---

A longer, structured exposure to understand the field and build context.

Use this for longer exposure via a course, fellowship, or series.
