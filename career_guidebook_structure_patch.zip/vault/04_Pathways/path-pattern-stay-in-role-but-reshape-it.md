---
kind: pathway
id: path-pattern-stay-in-role-but-reshape-it
title: Stay in role but reshape it
group: Path patterns
order: 1
---

Keep your current role, but adjust the scope, projects, or responsibilities to better match your strengths and constraints.
