---
kind: archived
id: module-entrepreneurship-founding
title: Entrepreneurship / founding
group: Orthogonal modules
---

# Entrepreneurship / founding

Orthogonal modules (cross-cutting, not cause-specific)
Used as additional options when they fit:
