---
kind: archived
id: module-project-first-create-an-artifact
title: Project-first (create an artifact)
group: Orthogonal modules
---

# Project-first (create an artifact)

Orthogonal modules (cross-cutting, not cause-specific)
Used as additional options when they fit:
