---
kind: pathway
id: experiment-d
title: Job-board scan (make roles concrete)
group: How to explore (A–D)
order: 0
---

Scan real roles to make the space concrete and identify skill gaps.

Use this to explore job boards to make roles/orgs concrete and bridge theory → action.
