---
kind: pathway
id: path-pattern-entrepreneurship-plan
title: Entrepreneurship plan
group: Path patterns
order: 10
---

Explore founding or building something new, starting with small experiments before big commitment.
