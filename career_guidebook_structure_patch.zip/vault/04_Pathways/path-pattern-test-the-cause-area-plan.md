---
kind: pathway
id: path-pattern-test-the-cause-area-plan
title: “Test the cause area” plan
group: Path patterns
order: 6
---

Run low-cost tests to learn whether a cause area fits before committing to a big switch.
