---
kind: pathway
id: path-pattern-adjacent-function-shift
title: Adjacent function shift
group: Path patterns
order: 3
---

Shift into a nearby role shape (e.g., research ↔ engineering ↔ policy/ops) without a full field change.
