---
kind: pathway
id: experiment-c
title: Hands-on project (proof of fit)
group: How to explore (A–D)
order: 0
---

Build a small artifact or join a mentored project to get real feedback and momentum.

Use this for hands-on momentum: a project pathway that creates proof of fit.
