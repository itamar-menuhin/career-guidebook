---
kind: archived
id: module-job-search-networking-sprint
title: Job search / networking sprint
group: Orthogonal modules
---

# Job search / networking sprint

Orthogonal modules (cross-cutting, not cause-specific)
Used as additional options when they fit:
