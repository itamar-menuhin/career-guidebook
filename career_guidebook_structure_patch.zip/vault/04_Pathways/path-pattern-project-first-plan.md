---
kind: pathway
id: path-pattern-project-first-plan
title: Project-first plan
group: Path patterns
order: 8
---

Start with a concrete project to learn fast, build proof of fit, and create a portfolio artifact.
