---
kind: pathway
id: path-pattern-networking-exposure-sprint-when-stuck
title: Networking/exposure sprint (when stuck)
group: Path patterns
order: 12
---

A short, intensive burst of conversations and exposure to break through uncertainty and generate options.
