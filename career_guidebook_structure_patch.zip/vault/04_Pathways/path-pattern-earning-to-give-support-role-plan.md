---
kind: pathway
id: path-pattern-earning-to-give-support-role-plan
title: Earning-to-give/support role plan
group: Path patterns
order: 11
---

Stay or move into roles that enable significant giving or support high-impact work indirectly.
