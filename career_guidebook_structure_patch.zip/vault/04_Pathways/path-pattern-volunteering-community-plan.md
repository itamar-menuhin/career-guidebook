---
kind: pathway
id: path-pattern-volunteering-community-plan
title: Volunteering/community plan
group: Path patterns
order: 9
---

Use volunteering or community roles to build network, credibility, and direction clarity.
