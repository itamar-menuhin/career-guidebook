---
kind: focus_area_bucket
focus_area_id: animal-welfare
bucket: hands-on
---


