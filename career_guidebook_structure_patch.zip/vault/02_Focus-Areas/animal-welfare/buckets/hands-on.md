## Experiment C — project pathway (make it concrete)
Canonical pick
Faunalytics volunteering — volunteers work with staff on projects meant to support animal advocates (i.e., real external users). Faunalytics+1
Optional alt
Use Animal Advocacy Careers volunteer opportunities to find an org + role where your contribution is directly used (campaign support, research support, ops, comms, etc.). Animal Advocacy Careers+1
Toe-in-the-water next step (≤60 min)
Pick one org type you’d be excited to support (campaign org / policy org / research org / ops-heavy nonprofit). Find 2–3 relevant roles on the job board and write 2 lines each: “why I could do this” + “what I’d need to learn.”
