## Experiment A — 1-hour overview (choose 1)
Canonical picks
80,000 Hours — Factory farming problem profile (skim; strong EA-style overview) 80,000 Hours
“Intro to effective animal advocacy” — Jacy Reese (EAGxBerkeley talk, YouTube) YouTube
Optional alt (if they’re more curious about wild animals specifically)
80,000 Hours — Wild animal welfare problem profile 80,000 Hours
