## Experiment D — job-board exploration (choose 1–2)
Canonical picks
Animal Advocacy Careers job board (animal-advocacy specific) Animal Advocacy Careers
80,000 Hours job board (filter toward animal welfare / relevant ops/policy roles) 80,000 Hours
Optional alt
EA Opportunities board (broader: fellowships, events, short programs, etc.) Effective Altruism
Tiny scanning method (10–25 min)
Same as AI safety: collect 8–12 roles → label role-types → circle 3 roles + 2 repeating skill gaps.
