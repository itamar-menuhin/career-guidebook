---
kind: focus_area
id: animal-welfare
title: 'Cause area: Animal Welfare quick-start (v1)'
summary: ''
role_shapes: []
fit_signals: []
---

## What it’s trying to achieve (plain language)

## What kinds of work exist here

## What a good fit often looks like (signals)
