---
kind: focus_area_bucket
focus_area_id: biosecurity
bucket: quick-taste
---

## Quick taste — 1-hour overview (choose 1)
- 80,000 Hours Biorisk research, strategy & policy career review (read/skim as an overview entry point). 80,000 Hours
- YouTube talk (EA-context): Jaime Yassif (biosecurity / GCBRs) talk (good “field picture” overview). YouTube
