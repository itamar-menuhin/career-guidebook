---
kind: focus_area_bucket
focus_area_id: biosecurity
bucket: deeper-dive
---

## Deeper dive — longer exposure (choose 1)
- BlueDot Impact — Biosecurity course (structured ~30h exposure). BlueDot+1
- Optional alt: pick 1–2 episodes/articles from 80,000 Hours’ biosecurity materials for deeper texture (e.g., health security interviews, misconceptions series). 80,000 Hours+280,000 Hours+2
