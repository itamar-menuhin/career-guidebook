## Experiment D — job-board exploration (bridge theory → action)
Canonical picks (choose 1–2)
80,000 Hours job board (filter for animal welfare, or AI/data roles in adjacent orgs).
Animal Advocacy Careers job board (search for data/tech roles; also helps you learn org landscape). (Animal Advocacy Careers)
Optional alt
EA Opportunities (often has fellowships/programs/projects that aren’t “jobs”). (Effective Altruism)
Tiny scanning method (10–25 min)
Collect 8–12 roles → label role type (ML / research / ops / policy) → circle 3 roles + 2 repeating skill gaps → turn that into a direction + next step.
