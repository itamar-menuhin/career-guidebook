---
kind: focus_area
id: ai-x-animals
title: 'Cause area: Animal × AI quick-start (v1)'
summary: ''
role_shapes: []
fit_signals: []
---

## What it’s trying to achieve (plain language)

## What kinds of work exist here

## What a good fit often looks like (signals)
