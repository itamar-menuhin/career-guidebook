---
kind: focus_area_bucket
focus_area_id: ai-safety
bucket: deeper-dive
---

## Deeper dive — longer exposure (choose 1)
- AGI Safety Fundamentals (reading group + discussion + project)
- BlueDot Impact AI courses (technical safety / governance)
