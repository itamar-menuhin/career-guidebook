---
kind: archived
focus_area_id: aixanimals
bucket: quick-taste
title: Quick taste (≈1 hour)
curated_cards: []
---

Experiment A — 1-hour overview (choose 1)
Canonical picks
Animal Charity Evaluators — “The impacts of AI on animal advocacy” (high-level framing of upsides/risks; good first map). (Animal Charity Evaluators)
Rethink Priorities — AI for human–wildlife conflict mitigations (concrete examples; “here’s what AI-for-animals can look like”). (Rethink Priorities)
Optional alt (if they want “how advocates already use AI”)
Faunalytics — “AI and Animal Advocacy” (survey-style view of current usage patterns). (Faunalytics)
