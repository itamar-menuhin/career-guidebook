## Experiment A — introductory resource (< 1 hour): wide overview + test interest
**Choose 1:**
- 80,000 Hours problem profile: Health in poor countries (Global health) (read/skim) (80,000 Hours)
- YouTube: GiveWell finds highly cost-effective charities — here’s how (good for the “why evidence?” mindset) (YouTube)
- Optional alt (more “why give effectively” than GH-specific): Peter Singer TED talk (via The Life You Can Save) (The Life You Can Save)
- Entrepreneurship orientation video (<1h)
- https://www.youtube.com/watch?v=rKmKLcYoixs
