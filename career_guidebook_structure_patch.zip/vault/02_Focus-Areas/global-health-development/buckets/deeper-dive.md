## Experiment B — longer exposure: understand the field with more granularity
**Choose 1:**
- (Non-EA but solid grounding) Coursera: An Introduction to Global Health (structured modules; builds vocabulary + systems map) (Coursera)
- Crash Course playlist: Public Health (lighter but sticky; good for people who prefer video series) (YouTube)
