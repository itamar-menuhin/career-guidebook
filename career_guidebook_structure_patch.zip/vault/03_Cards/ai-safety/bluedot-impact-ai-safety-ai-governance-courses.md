---
kind: archived
id: bluedot-impact-ai-safety-ai-governance-courses
title: 'BlueDot Impact: AI Safety / AI Governance courses'
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


