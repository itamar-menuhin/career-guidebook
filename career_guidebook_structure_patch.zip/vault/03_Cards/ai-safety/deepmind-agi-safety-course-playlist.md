---
kind: archived
id: deepmind-agi-safety-course-playlist
title: 'DeepMind: “AGI Safety Course” (playlist)'
focus_area_id: ai-safety
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


