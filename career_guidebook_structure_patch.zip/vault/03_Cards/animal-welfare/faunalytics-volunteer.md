---
kind: card
id: animal-welfare-card-06
title: Faunalytics — Volunteer
focus_area_id: animal-welfare
bucket: hands-on
topic: project
commitment: Light–Medium
one_liner: Do externally useful work that animal advocates use (measurable good; not
  a portfolio exercise).
links:
- https://faunalytics.org/volunteer/
---

Do externally useful work that animal advocates use (measurable good; not a portfolio exercise).

## When to suggest
- Candidate wants a concrete project with real beneficiaries
- Candidate likes research/analysis/writing/data/ops support

## When not to
- Candidate can’t commit to any deadlines at all right now

## Resources / links
- https://faunalytics.org/volunteer/
