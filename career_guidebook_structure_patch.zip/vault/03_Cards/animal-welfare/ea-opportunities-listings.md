---
kind: card
id: animal-welfare-card-10
title: EA Opportunities — listings
focus_area_id: animal-welfare
bucket: job-board
topic: community
commitment: Tiny (≤1h)
one_liner: 'Broader than jobs: fellowships/events/short programs; useful as an “entry
  ramp.”'
links:
- https://www.effectivealtruism.org/opportunities
---

Broader than jobs: fellowships/events/short programs; useful as an “entry ramp.”

## When to suggest
- Candidate wants programs/fellowships more than job listings

## When not to
- Candidate gets overwhelmed by broad lists (pick one specific program instead)

## Resources / links
- https://www.effectivealtruism.org/opportunities
