---
kind: card
id: climate-card-07
title: 'Project: Giving drive informed by Giving Green'
focus_area_id: climate
bucket: hands-on
topic: project
commitment: Light
one_liner: 'A measurable-good project for action-first candidates: $ influenced /
  donated toward vetted opportunities. Giving Green+1'
links:
- https://www.givinggreen.earth/top-climate-nonprofits Giving Green
---

A measurable-good project for action-first candidates: $ influenced / donated toward vetted opportunities. Giving Green+1

## When to suggest
- Candidate needs action to stay motivated or wants quick proof-of-fit
- Candidate is comfortable doing a small outreach or workplace match

## When not to
- Candidate is uncomfortable asking others (then suggest direct giving or job-board scanning)
- Draft one short message + send to 5–10 people with a clear donation endpoint and a small target.

## Resources / links
- https://www.givinggreen.earth/top-climate-nonprofits Giving Green
