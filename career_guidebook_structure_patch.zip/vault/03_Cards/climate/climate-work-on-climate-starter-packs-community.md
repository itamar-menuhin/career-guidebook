---
kind: archived
id: climate-work-on-climate-starter-packs-community
title: 'Work on Climate: Starter Packs + community'
focus_area_id: climate
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


