---
kind: card
id: ai-x-animals-card-06
title: Terra.do fellowship
focus_area_id: ai-x-animals
bucket: quick-taste
topic: program
commitment: Medium
one_liner: ''
links:
- https://80000hours.org/podcast/episodes/johannes-ackva-unfashionable-climate-interventions/
- https://80000hours.org/problem-profiles/climate-change/
- https://climatebase.org/jobs
- https://jobs.80000hours.org/
- https://jobs.probablygood.org/?cause=Climate+Change
- https://probablygood.org/cause-areas/climate-change/careers/
- https://probablygood.org/cause-areas/climate-change/overview/
- https://workonclimate.org/
- https://workonclimate.org/starter-packs/
- https://www.founderspledge.com/funds/climate-fund/about
- https://www.founderspledge.com/research/climate-change-executive-summary
- https://www.givinggreen.earth/top-climate-nonprofits
- https://www.givingwhatwecan.org/charities/founders-pledge-climate-change-fund
- https://www.youtube.com/playlist?list=PLwYnpej4pQF7sB5_ZmS2IjFae5M7MafiF
---

## Resources / links
- https://80000hours.org/podcast/episodes/johannes-ackva-unfashionable-climate-interventions/
- https://80000hours.org/problem-profiles/climate-change/
- https://climatebase.org/jobs
- https://jobs.80000hours.org/
- https://jobs.probablygood.org/?cause=Climate+Change
- https://probablygood.org/cause-areas/climate-change/careers/
- https://probablygood.org/cause-areas/climate-change/overview/
- https://workonclimate.org/
- https://workonclimate.org/starter-packs/
- https://www.founderspledge.com/funds/climate-fund/about
- https://www.founderspledge.com/research/climate-change-executive-summary
- https://www.givinggreen.earth/top-climate-nonprofits
- https://www.givingwhatwecan.org/charities/founders-pledge-climate-change-fund
- https://www.youtube.com/playlist?list=PLwYnpej4pQF7sB5_ZmS2IjFae5M7MafiF
