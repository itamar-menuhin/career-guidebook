---
kind: card
id: ai-x-animals-card-04
title: Rethink Priorities — How AI is affecting farmed aquatic animals (series) Rethink
  Priorities+1
focus_area_id: ai-x-animals
bucket: deeper-dive
topic: course
commitment: Medium
one_liner: Deep “EA research-y” analysis of innovation → deployment → welfare impacts
  in aquaculture.
links: []
---

Deep “EA research-y” analysis of innovation → deployment → welfare impacts in aquaculture.

## When to suggest
- Candidate likes research depth and wants to understand mechanisms and intervention hooks
- Candidate is interested in farmed animals / food systems + technology

## When not to
- Candidate needs a structured cohort and peers rather than self-study (use fellowships)
