---
kind: card
id: ai-x-animals-card-05
title: Founders Pledge Climate Fund / Climate Change Fund (via GWWC page)
focus_area_id: ai-x-animals
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: ''
links: []
---


