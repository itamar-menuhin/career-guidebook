---
kind: card
id: ai-x-animals-card-03
title: 'Giving What We Can: Global Health & Wellbeing Fund'
focus_area_id: ai-x-animals
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: ''
links: []
---


