---
kind: card
id: ai-x-animals-card-03
title: Work on Climate (Starter Packs + community)
focus_area_id: ai-x-animals
bucket: quick-taste
topic: community
commitment: Tiny
one_liner: ''
links: []
---


