---
kind: card
id: ai-x-animals-card-05
title: Charity Entrepreneurship Incubation Program
focus_area_id: ai-x-animals
bucket: quick-taste
topic: program
commitment: High
one_liner: ''
links:
- https://80000hours.org/problem-profiles/health-in-poor-countries/
- https://www.charityentrepreneurship.com/
- https://www.charityentrepreneurship.com/apply
- https://www.coursera.org/learn/global-health-introduction
- https://www.givewell.org/charities/top-charities
- https://www.givewell.org/how-we-work/our-criteria/cost-effectiveness/cost-effectiveness-models
- https://www.givingwhatwecan.org/charities/global-health-and-wellbeing-fund
- https://www.givingwhatwecan.org/pledge
- https://www.thelifeyoucansave.org/best-charities/
- https://www.thelifeyoucansave.org/peter-singers-ted-talk/
- https://www.youtube.com/playlist?list=PL8dPuuaLjXtPjQj_LcJ0Zvj-VI3sslJyF
- https://www.youtube.com/watch?v=_TqabsxdWmo
---

## Resources / links
- https://80000hours.org/problem-profiles/health-in-poor-countries/
- https://www.charityentrepreneurship.com/
- https://www.charityentrepreneurship.com/apply
- https://www.coursera.org/learn/global-health-introduction
- https://www.givewell.org/charities/top-charities
- https://www.givewell.org/how-we-work/our-criteria/cost-effectiveness/cost-effectiveness-models
- https://www.givingwhatwecan.org/charities/global-health-and-wellbeing-fund
- https://www.givingwhatwecan.org/pledge
- https://www.thelifeyoucansave.org/best-charities/
- https://www.thelifeyoucansave.org/peter-singers-ted-talk/
- https://www.youtube.com/playlist?list=PL8dPuuaLjXtPjQj_LcJ0Zvj-VI3sslJyF
- https://www.youtube.com/watch?v=_TqabsxdWmo
