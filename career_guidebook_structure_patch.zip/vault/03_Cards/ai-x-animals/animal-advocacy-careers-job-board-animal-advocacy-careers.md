---
kind: card
id: ai-x-animals-card-10
title: Animal Advocacy Careers — Job board Animal Advocacy Careers
focus_area_id: ai-x-animals
bucket: job-board
topic: reading
commitment: Tiny
one_liner: Best place to see animal-advocacy orgs and spot tech/data roles that could
  connect to AI-for-animals.
links:
- https://animaladvocacycareers.org/job-board/ Animal Advocacy Careers
---

Best place to see animal-advocacy orgs and spot tech/data roles that could connect to AI-for-animals.

## When to suggest
- Candidate wants to translate interest into “what roles exist?”
- Candidate wants to learn org landscape fast

## When not to
- Candidate gets overwhelmed by job boards (use A/B first)

## Resources / links
- https://animaladvocacycareers.org/job-board/ Animal Advocacy Careers
