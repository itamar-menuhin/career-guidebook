---
kind: card
id: ai-x-animals-card-06
title: Futurekind AI Fellowship (EA Opportunities / Electric Sheep) Effective Altruism+2Electric
  Sheep+2
focus_area_id: ai-x-animals
bucket: deeper-dive
topic: program
commitment: Medium
one_liner: 12-week program to build skills and projects around AI for animal protection
  / environmental impact.
links: []
---

12-week program to build skills and projects around AI for animal protection / environmental impact.

## When to suggest
- Candidate wants a longer, project-forward structured program
- Candidate wants to build or research in this space with mentorship/community

## When not to
- Candidate can’t commit to 12 weeks; use AI×Animals (8 weeks) or Experiment A first
