---
kind: card
id: ai-x-animals-card-02
title: '80,000 Hours: Climate change problem profile'
focus_area_id: ai-x-animals
bucket: quick-taste
topic: course
commitment: Tiny–Light
one_liner: ''
links: []
---


