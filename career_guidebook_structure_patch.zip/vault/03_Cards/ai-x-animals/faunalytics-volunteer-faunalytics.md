---
kind: card
id: ai-x-animals-card-09
title: Faunalytics — Volunteer Faunalytics
focus_area_id: ai-x-animals
bucket: hands-on
topic: project
commitment: Light–Medium
one_liner: Contribute to work that supports animal advocates; good if your contribution
  can be directly used (analysis, tooling, research support).
links: []
---

Contribute to work that supports animal advocates; good if your contribution can be directly used (analysis, tooling, research support).

## When to suggest
- Candidate wants a real-world contribution but doesn’t have specialized ML deployment skills
- Candidate can support research/tooling/analysis

## When not to
- Candidate can’t commit to any deadlines or deliverables
