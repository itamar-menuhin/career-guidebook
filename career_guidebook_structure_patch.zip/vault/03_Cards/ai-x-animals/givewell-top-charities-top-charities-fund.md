---
kind: card
id: ai-x-animals-card-01
title: GiveWell top charities / Top Charities Fund
focus_area_id: ai-x-animals
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: ''
links: []
---


