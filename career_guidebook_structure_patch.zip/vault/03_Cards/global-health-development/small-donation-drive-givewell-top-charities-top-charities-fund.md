---
kind: card
id: global-health-development-card-09
title: Small donation drive → GiveWell Top Charities / Top Charities Fund
focus_area_id: global-health-development
bucket: hands-on
topic: project
commitment: Light
one_liner: 'Measurable-good project: money moved to highly cost-effective programs.
  GiveWell+1'
links:
- https://www.givewell.org/charities/top-charities GiveWell
- https://www.givewell.org/top-charities-fund GiveWell
---

Measurable-good project: money moved to highly cost-effective programs. GiveWell+1

## When to suggest
- Candidate needs action to stay motivated / wants proof-of-fit fast
- Candidate is donation-positive and can do small outreach

## When not to
- Candidate is very uncomfortable asking others for money

## Resources / links
- https://www.givewell.org/charities/top-charities GiveWell
- https://www.givewell.org/top-charities-fund GiveWell
