---
kind: archived
id: peter-singer-ted-talk-via-the-life-you-can-save
title: Peter Singer TED talk (via The Life You Can Save)
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


