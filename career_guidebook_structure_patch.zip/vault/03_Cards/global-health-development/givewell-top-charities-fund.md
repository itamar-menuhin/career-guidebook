---
kind: card
id: global-health-development-card-06
title: GiveWell — Top Charities Fund
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: Low-friction “default option” for giving to GiveWell’s highest-priority
  funding needs. GiveWell+1
links:
- https://www.givewell.org/top-charities-fund GiveWell
---

Low-friction “default option” for giving to GiveWell’s highest-priority funding needs. GiveWell+1

## When to suggest
- Candidate wants a default giving option without picking a single org

## When not to
- Candidate wants to choose the org themselves

## Resources / links
- https://www.givewell.org/top-charities-fund GiveWell
