---
kind: archived
id: 80-000-hours-health-in-poor-countries-problem-profile
title: '80,000 Hours: Health in poor countries (problem profile)'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


