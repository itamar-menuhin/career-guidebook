---
kind: card
id: global-health-development-card-12
title: Charity Entrepreneurship — Incubation Program
focus_area_id: global-health-development
bucket: quick-taste
topic: program
commitment: High
one_liner: EA-aligned, high-commitment path to founding a cost-effective charity with
  training, research, and network. CE+1
links:
- https://www.charityentrepreneurship.com/ CE
- https://www.charityentrepreneurship.com/apply CE
---

EA-aligned, high-commitment path to founding a cost-effective charity with training, research, and network. CE+1

## When to suggest
- Candidate is genuinely excited by founding
- Candidate can handle an intensive period + in-person component

## When not to
- Candidate is not open to relocation / high intensity

## Resources / links
- https://www.charityentrepreneurship.com/ CE
- https://www.charityentrepreneurship.com/apply CE
