---
kind: archived
id: givewell-top-charities
title: 'GiveWell: Top Charities'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


