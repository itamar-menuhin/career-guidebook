---
kind: archived
id: global-health-development-giving-what-we-can-10-pledge
title: 'Giving What We Can: 10% Pledge'
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


