---
kind: card
id: global-health-development-card-11
title: The Life You Can Save — Best Charities
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: EA-adjacent, evidence-backed recommended charity list with accessible explanations.
  The Life You Can Save+1
links:
- https://www.thelifeyoucansave.org/best-charities/ The Life You Can Save
---

EA-adjacent, evidence-backed recommended charity list with accessible explanations. The Life You Can Save+1

## When to suggest
- Candidate wants an approachable curated list and narratives

## When not to
- Candidate wants strictly “GiveWell-only” style

## Resources / links
- https://www.thelifeyoucansave.org/best-charities/ The Life You Can Save
