---
kind: card
id: global-health-development-card-08
title: Giving What We Can — Pledge
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: A commitment mechanism for people who want giving to be a stable part of
  life. Wikipedia
links:
- https://www.givingwhatwecan.org/pledge
---

A commitment mechanism for people who want giving to be a stable part of life. Wikipedia

## When to suggest
- Candidate explicitly likes commitment devices and is financially comfortable

## When not to
- Candidate is stressed by commitments or finances are uncertain

## Resources / links
- https://www.givingwhatwecan.org/pledge
