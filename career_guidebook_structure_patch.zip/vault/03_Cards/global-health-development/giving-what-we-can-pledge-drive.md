---
kind: card
id: global-health-development-card-10
title: Giving What We Can — Pledge Drive
focus_area_id: global-health-development
bucket: hands-on
topic: project
commitment: Light
one_liner: 'Measurable-good community action: pledges taken / giving committed. Giving
  What We Can'
links:
- https://www.givingwhatwecan.org/events/pledge-drive Giving What We Can
---

Measurable-good community action: pledges taken / giving committed. Giving What We Can

## When to suggest
- Candidate likes community action and structured campaigns

## When not to
- Candidate is pledge-averse or feels pressure around commitments

## Resources / links
- https://www.givingwhatwecan.org/events/pledge-drive Giving What We Can
