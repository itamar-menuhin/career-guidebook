---
kind: card
id: global-health-development-card-07
title: GWWC — Global Health and Wellbeing Fund
focus_area_id: global-health-development
bucket: quick-taste
topic: reading
commitment: Tiny
one_liner: Pooled giving allocated periodically using evaluator input (explicitly
  consults GiveWell). Giving What We Can
links:
- https://www.givingwhatwecan.org/charities/global-health-and-wellbeing-fund Giving
  What We Can
---

Pooled giving allocated periodically using evaluator input (explicitly consults GiveWell). Giving What We Can

## When to suggest
- Candidate likes pooled funds and evaluator-guided allocation

## When not to
- Candidate wants to pick specific charities

## Resources / links
- https://www.givingwhatwecan.org/charities/global-health-and-wellbeing-fund Giving What We Can
