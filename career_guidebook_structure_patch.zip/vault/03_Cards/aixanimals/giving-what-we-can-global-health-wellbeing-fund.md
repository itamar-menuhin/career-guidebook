---
kind: archived
id: giving-what-we-can-global-health-wellbeing-fund
title: 'Giving What We Can: Global Health & Wellbeing Fund'
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: donate once; it’s allocated periodically using evaluator input (incl.
  GiveWell). (Giving What We Can)
---

## First small step
donate once; it’s allocated periodically using evaluator input (incl. GiveWell). (Giving What We Can)
