---
kind: archived
id: probably-good-climate-careers-guide
title: 'Probably Good: Climate careers guide'
focus_area_id: aixanimals
bucket: quick-taste
topic: course
commitment: low
good_fit_if:
- Open
first_small_step: skim the “recommended jobs” list and circle 2 role-shapes to test.
  Probably Good+1
---

## First small step
skim the “recommended jobs” list and circle 2 role-shapes to test. Probably Good+1
