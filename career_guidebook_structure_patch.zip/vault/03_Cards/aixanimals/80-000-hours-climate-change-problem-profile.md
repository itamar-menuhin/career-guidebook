---
kind: archived
id: 80-000-hours-climate-change-problem-profile
title: '80,000 Hours: Climate change problem profile'
focus_area_id: aixanimals
bucket: quick-taste
topic: course
commitment: low
good_fit_if:
- Open
first_small_step: read “best ways of working” + note 2 levers you’d be willing to
  explore. 80,000 Hours
---

## First small step
read “best ways of working” + note 2 levers you’d be willing to explore. 80,000 Hours
