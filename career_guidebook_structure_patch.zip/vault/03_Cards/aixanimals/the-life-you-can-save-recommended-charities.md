---
kind: archived
id: the-life-you-can-save-recommended-charities
title: 'The Life You Can Save: recommended charities'
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: pick one recommended charity and read its “why recommended” page.
  (The Life You Can Save)
---

## First small step
pick one recommended charity and read its “why recommended” page. (The Life You Can Save)
