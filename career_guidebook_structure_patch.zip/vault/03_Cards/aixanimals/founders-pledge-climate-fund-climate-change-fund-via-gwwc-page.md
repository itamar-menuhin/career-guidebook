---
kind: archived
id: founders-pledge-climate-fund-climate-change-fund-via-gwwc-page
title: Founders Pledge Climate Fund / Climate Change Fund (via GWWC page)
focus_area_id: aixanimals
bucket: quick-taste
topic: project
commitment: low
good_fit_if:
- Open
first_small_step: skim the executive summary + decide whether “giving” is a satisfying
  lever for them. Founders Pledge+2Giving What We Can+2
---

## First small step
skim the executive summary + decide whether “giving” is a satisfying lever for them. Founders Pledge+2Giving What We Can+2
