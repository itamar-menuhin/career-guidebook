---
kind: archived
id: jaime-yassif-reducing-global-catastrophic-biological-risks-youtube
title: 'Jaime Yassif: “Reducing global catastrophic biological risks” (YouTube)'
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


