---
kind: archived
id: 80-000-hours-biosecurity-materials-topic-archive-podcasts
title: '80,000 Hours: Biosecurity materials (topic archive / podcasts)'
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


