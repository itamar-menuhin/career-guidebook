---
kind: archived
id: 80-000-hours-job-board-filter-to-biosecurity-pandemic-preparedness
title: 80,000 Hours Job Board (filter to biosecurity & pandemic preparedness)
focus_area_id: biosecurity
bucket: quick-taste
topic: reading
commitment: low
good_fit_if:
- Open
---


