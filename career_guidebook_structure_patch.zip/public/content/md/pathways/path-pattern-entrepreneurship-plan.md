# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Explore founding or building something new, starting with small experiments before big commitment.
