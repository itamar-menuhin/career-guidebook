# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

A bigger pivot into a new field or role family, usually via deliberate exploration and skill-building steps.
