# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Build a small artifact or join a mentored project to get real feedback and momentum.

Use this for hands-on momentum: a project pathway that creates proof of fit.
