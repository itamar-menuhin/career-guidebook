# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Keep your current role, but adjust the scope, projects, or responsibilities to better match your strengths and constraints.
