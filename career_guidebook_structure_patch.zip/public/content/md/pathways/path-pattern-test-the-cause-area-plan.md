# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Run low-cost tests to learn whether a cause area fits before committing to a big switch.
