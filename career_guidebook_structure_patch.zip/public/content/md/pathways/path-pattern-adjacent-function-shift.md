# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Shift into a nearby role shape (e.g., research ↔ engineering ↔ policy/ops) without a full field change.
