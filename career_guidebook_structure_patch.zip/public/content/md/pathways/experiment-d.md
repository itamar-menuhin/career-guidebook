# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Scan real roles to make the space concrete and identify skill gaps.

Use this to explore job boards to make roles/orgs concrete and bridge theory → action.
