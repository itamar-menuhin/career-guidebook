# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Stay or move into roles that enable significant giving or support high-impact work indirectly.
