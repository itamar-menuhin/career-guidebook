# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

A fast way to get oriented and test interest without commitment.

Use this as an overview + interest test; pick one canonical intro resource/video.
