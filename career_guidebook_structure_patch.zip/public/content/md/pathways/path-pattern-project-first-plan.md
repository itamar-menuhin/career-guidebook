# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Start with a concrete project to learn fast, build proof of fit, and create a portfolio artifact.
