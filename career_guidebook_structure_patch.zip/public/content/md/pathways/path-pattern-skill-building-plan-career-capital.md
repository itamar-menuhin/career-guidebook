# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Invest in skills, credentials, or portfolio work to unlock higher-impact options later.
