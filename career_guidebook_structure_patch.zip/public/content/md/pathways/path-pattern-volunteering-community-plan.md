# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Use volunteering or community roles to build network, credibility, and direction clarity.
