# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Use a formal program, fellowship, or credential as a structured on-ramp into a new area.
