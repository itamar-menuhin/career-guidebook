# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

A short, intensive burst of conversations and exposure to break through uncertainty and generate options.
