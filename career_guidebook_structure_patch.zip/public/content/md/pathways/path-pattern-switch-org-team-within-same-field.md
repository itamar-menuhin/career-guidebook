# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

Move to a different team or organization while staying in the same general domain to improve fit, learning, or impact.
