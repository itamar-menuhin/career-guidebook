# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

A longer, structured exposure to understand the field and build context.

Use this for longer exposure via a course, fellowship, or series.
