# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

# Cause-area quick-start page template (locked)

## Cause area name
- What this area is trying to achieve (2–4 lines, plain language)
- What kinds of work exist here (role shapes, not org names)
- What a “good fit” often looks like (signals, not requirements)
- Experiments (pick the ones that fit the person)

## Quick taste (≈1 hour)
Broad overview + interest test; canonical intro resource/video (1–2 options)

## Deeper dive (course / fellowship)
Longer exposure: course/fellowship/series; field granularity (1–2 options)

## Hands-on project (proof of fit)
Project pathway: hands-on; proof-of-fit; motivation-from-action; also good for people needing a push / impostor syndrome

## Job-board scan (make roles concrete)
Job-board exploration: make roles/orgs concrete + bridge theory→action (boards + quick scan method)

## Go-to recommendations (2–6 cards)

## Who to talk to (intro types + 3 questions max)

## Common confusions (optional)

## Notes for you (internal)
