# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

## Quick taste — 1-hour overview (choose 1)
- Robert Miles — “Intro to AI Safety, Remastered” (video)
- DeepMind — “AGI Safety Course” playlist (video course)
- Optional alt if they prefer reading: 80,000 Hours AI safety researcher career review
