# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

## Deeper dive — longer exposure (choose 1)
- AGI Safety Fundamentals (reading group + discussion + project)
- BlueDot Impact AI courses (technical safety / governance)
