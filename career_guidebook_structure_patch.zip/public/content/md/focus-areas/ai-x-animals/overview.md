# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

## What it’s trying to achieve (plain language)

## What kinds of work exist here

## What a good fit often looks like (signals)
