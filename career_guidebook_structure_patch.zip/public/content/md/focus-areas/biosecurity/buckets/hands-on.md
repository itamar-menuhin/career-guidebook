# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

## Hands-on project — project pathway (make it concrete)
- Canonical pick: Oxford Biosecurity Group (OBG) projects (part-time remote research projects; biosecurity + AI-bio intersection). My Site+1
- Toe-in-the-water step: browse the projects page; pick 2 projects that seem feasible/interesting; write 2 lines each.
