# GENERATED FROM VAULT — DO NOT EDIT. Source of truth: /vault

## Job-board scan — job-board exploration (choose 1–2)
- 80,000 Hours job board (filter toward biosecurity/pandemic preparedness roles). 80,000 Hours Job Board+1
- Optional alt: EA Opportunities for events/fellowships/short programs in biosecurity. Effective Altruism
- Tiny scanning method (10–25 min): same as AI safety (8–12 roles → label → circle 3 roles + 2 skill gaps).
- Biosecurity — Recommendation Cards
